package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import net.PhpTravels.constants.AutomationConstants;
import net.PhpTravels.pages.AdminBackEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassAdmBackEnd_Login extends TestBase{

	AdminBackEnd AdmBaEnd;
	
	@Test(priority=3)
	public void TC026_VerifyLoginValid() throws IOException {
		AdmBaEnd = new AdminBackEnd(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AdmBaEnd.clearEmail();
		AdmBaEnd.clearPassword();
		AdmBaEnd.setEmail(ExcelUtility.getCellDataAdmin(1, 0));
		AdmBaEnd.setPassword(ExcelUtility.getCellDataAdmin(1, 1));
		AdmBaEnd.login.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("AdminDashboard");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Exp,Act);
	}
	
	@Test(priority=1)
	public void TC027_VerifyLoginInvalidEmail() throws IOException, InterruptedException {
		AdmBaEnd = new AdminBackEnd(driver);
		driver.get(prop.getProperty("AdminLogin"));
	  driver.manage().window().maximize(); 
	  AdmBaEnd.setEmail(ExcelUtility.getCellDataAdmin(2, 0));
	  AdmBaEnd.setPassword(ExcelUtility.getCellDataAdmin(2, 1));
	  AdmBaEnd.login.click();
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement el = wait.until(ExpectedConditions.presenceOfElementLocated
				(By.xpath("//div[@class='alert alert-danger loading wow fadeIn animated animated']")));   
		Assert.assertTrue(el.getText().contains(AutomationConstants.BACKEND_LOGIN_ERROR_MESSAGE));
	}
	
	@Test(priority=2)
	public void TC028_VerifyLoginInvalidPassword() throws IOException, InterruptedException {
		AdmBaEnd = new AdminBackEnd(driver);
		AdmBaEnd.clearEmail();
		AdmBaEnd.clearPassword();
		AdmBaEnd.setEmail(ExcelUtility.getCellDataAdmin(3, 0));
		AdmBaEnd.setPassword(ExcelUtility.getCellDataAdmin(3, 1));
		AdmBaEnd.login.click();
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement el = wait.until(ExpectedConditions.presenceOfElementLocated
						(By.xpath("//div[@class='alert alert-danger loading wow fadeIn animated animated']")));   
		Assert.assertTrue(el.getText().contains(AutomationConstants.BACKEND_LOGIN_ERROR_MESSAGE));
	}
	
	
	
}
