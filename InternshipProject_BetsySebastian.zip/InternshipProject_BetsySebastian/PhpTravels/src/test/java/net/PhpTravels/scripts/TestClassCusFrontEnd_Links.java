package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import net.PhpTravels.pages.CustomerFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassCusFrontEnd_Links extends TestBase{
	
CustomerFrontEnd CustFrEnd;
	

	@BeforeClass
	public void Login() throws IOException {
		CustFrEnd = new CustomerFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
	  driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		CustFrEnd.setEmail(ExcelUtility.getCellDataCustomer(1, 0));
		CustFrEnd.setPassword(ExcelUtility.getCellDataCustomer(1, 1));
		CustFrEnd.login.click();
	}
	
	@Test (priority=2)
	public void TC004_VerifyBookingsLink() {
		CustFrEnd = new CustomerFrontEnd(driver);
		CustFrEnd.myBookings.click();
		String Exp = prop.getProperty("FrontEndBookings");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
	}

	@Test (priority=3)
	public void TC005_VerifyAddFundLink() {
		CustFrEnd = new CustomerFrontEnd(driver);
		CustFrEnd.addFund.click();
		String Exp = prop.getProperty("FrontEndAddFunds");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
	}
	
	@Test (priority=4)
	public void TC006_VerifyMyProfileLink() {
		CustFrEnd = new CustomerFrontEnd(driver);
		CustFrEnd.myProfile.click();
		String Exp = prop.getProperty("FrontEndProfile");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
	}
	
	@Test (priority=5)
	public void TC007_VerifyLogoutLink() {
		CustFrEnd = new CustomerFrontEnd(driver);
		CustFrEnd.Logout.click();
		String Exp = prop.getProperty("FrontEndLogin");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
	}
	
}
