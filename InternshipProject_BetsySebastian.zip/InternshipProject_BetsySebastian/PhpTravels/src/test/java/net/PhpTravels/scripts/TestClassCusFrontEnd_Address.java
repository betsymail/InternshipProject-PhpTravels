package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import net.PhpTravels.pages.CustomerFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassCusFrontEnd_Address extends TestBase{
	
CustomerFrontEnd CustFrEnd;
	

	@BeforeClass
	public void Login() throws IOException {
		CustFrEnd = new CustomerFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
	  driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		CustFrEnd.setEmail(ExcelUtility.getCellDataCustomer(1, 0));
		CustFrEnd.setPassword(ExcelUtility.getCellDataCustomer(1, 1));
		CustFrEnd.login.click();
	}
	
	@Test (priority=1)
	public void TC012_VerifyUpdateAddress() throws InterruptedException{
		CustFrEnd = new CustomerFrontEnd(driver);
		CustFrEnd.myProfile.click();
		
		WebElement l=driver.findElement(By.xpath("//input[contains(@name,'address1')]"));
    ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", l);
    Thread.sleep(300);
    
		CustFrEnd.Address1.clear();
		CustFrEnd.Address1.sendKeys("S81 Lane, Texas - 1");
		String Exp = CustFrEnd.Address1.getAttribute("value");
		String Act = "S81 Lane, Texas - 1";
		Assert.assertEquals(Act, Exp);
	}
	
	@Test (priority=2)
	public void TC013_VerifyUpdateAddress2() throws InterruptedException{
		CustFrEnd = new CustomerFrontEnd(driver);
		CustFrEnd.myProfile.click();
		
		WebElement l=driver.findElement(By.xpath("//input[contains(@name,'address2')]"));
    ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", l);
    Thread.sleep(300);
    
    CustFrEnd.Address2.clear();
		CustFrEnd.Address2.sendKeys("Moraco county");
		String AddExp = CustFrEnd.Address2.getAttribute("value");
		String AddAct = "Moraco county";
		Assert.assertEquals(AddAct, AddExp);
		
	}
    
	@Test (priority=3)
	public void TC014_VerifyPageScroll() throws InterruptedException{
		CustFrEnd = new CustomerFrontEnd(driver);
		JavascriptExecutor jse= (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,500)");	
		jse.executeScript("window.scrollBy(0,-500)");
	}
}
