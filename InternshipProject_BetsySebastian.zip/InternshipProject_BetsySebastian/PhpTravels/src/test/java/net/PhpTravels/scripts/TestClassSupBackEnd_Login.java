package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import net.PhpTravels.constants.AutomationConstants;
import net.PhpTravels.pages.SupplierBackEnd;

import net.PhpTravels.utilities.ExcelUtility;

public class TestClassSupBackEnd_Login extends TestBase{

SupplierBackEnd SupBaEnd;
	
	@Test(priority=3)
	public void TC033_VerifyLoginValid() throws IOException {
		SupBaEnd = new SupplierBackEnd(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		SupBaEnd.clearEmail();
		SupBaEnd.clearPassword();
		SupBaEnd.setEmail(ExcelUtility.getCellDataSupplier(1, 0));
		SupBaEnd.setPassword(ExcelUtility.getCellDataSupplier(1, 1));
		SupBaEnd.login.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("SupplierDashboard");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Exp,Act);
	}
	
	@Test(priority=1)
	public void TC034_VerifyLoginInvalidEmail() throws IOException, InterruptedException {
		SupBaEnd = new SupplierBackEnd(driver);
		driver.get(prop.getProperty("SupplierLogin"));
	  driver.manage().window().maximize(); 
	  SupBaEnd.setEmail(ExcelUtility.getCellDataSupplier(2, 0));
	  SupBaEnd.setPassword(ExcelUtility.getCellDataSupplier(2, 1));
	  SupBaEnd.login.click();
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement el = wait.until(ExpectedConditions.presenceOfElementLocated
				(By.xpath("//div[@class='alert alert-danger loading wow fadeIn animated animated']")));   
		Assert.assertTrue(el.getText().contains(AutomationConstants.BACKEND_LOGIN_ERROR_MESSAGE));
	}
	
	@Test(priority=2)
	public void TC035_VerifyLoginInvalidPassword() throws IOException, InterruptedException {
		SupBaEnd = new SupplierBackEnd(driver);
		SupBaEnd.clearEmail();
		SupBaEnd.clearPassword();
		SupBaEnd.setEmail(ExcelUtility.getCellDataSupplier(3, 0));
		SupBaEnd.setPassword(ExcelUtility.getCellDataSupplier(3, 1));
		SupBaEnd.login.click();
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement el = wait.until(ExpectedConditions.presenceOfElementLocated
						(By.xpath("//div[@class='alert alert-danger loading wow fadeIn animated animated']")));   
		Assert.assertTrue(el.getText().contains(AutomationConstants.BACKEND_LOGIN_ERROR_MESSAGE));
	}
	
}
