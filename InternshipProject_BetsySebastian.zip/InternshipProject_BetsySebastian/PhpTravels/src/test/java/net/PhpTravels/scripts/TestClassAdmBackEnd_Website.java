package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import net.PhpTravels.pages.AdminBackEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassAdmBackEnd_Website extends TestBase{
	
AdminBackEnd AdmBaEnd;
	
@BeforeClass
public void Login() throws IOException {
			AdmBaEnd = new AdminBackEnd(driver);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(prop.getProperty("AdminLogin"));
		  driver.manage().window().maximize(); 
			AdmBaEnd.setEmail(ExcelUtility.getCellDataAdmin(1, 0));
			AdmBaEnd.setPassword(ExcelUtility.getCellDataAdmin(1, 1));
			AdmBaEnd.login.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			String Exp = prop.getProperty("AdminDashboard");
			String Act = driver.getCurrentUrl();
			Assert.assertEquals(Exp,Act);
		}

@Test(priority=1)
public void TC032_VerifyWebsiteLink() throws InterruptedException {
		AdmBaEnd = new AdminBackEnd(driver);
		AdmBaEnd.websiteLink.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
	  driver.switchTo().window(tabs2.get(1));
	  String ActualString = driver.getCurrentUrl();
	  Assert.assertEquals(ActualString, prop.getProperty("WebsiteLink"));
	  driver.close();
	   
	  driver.switchTo().window(tabs2.get(0));
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  String CurrentExp = prop.getProperty("AdminDashboard");
		String CurrentAct = driver.getCurrentUrl();
		Assert.assertEquals(CurrentAct, CurrentExp);
		 
	}
		
}


