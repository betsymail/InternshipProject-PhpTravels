package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import net.PhpTravels.constants.AutomationConstants;
import net.PhpTravels.pages.AdminBackEnd;
import net.PhpTravels.pages.CustomerFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassAdmBackEnd_Bookings extends TestBase {

	AdminBackEnd AdmBaEnd;
	CustomerFrontEnd CustFrEnd;

	@BeforeClass
	public void Login() throws IOException {
		CustFrEnd = new CustomerFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		CustFrEnd.setEmail(ExcelUtility.getCellDataCustomer(1, 0));
		CustFrEnd.setPassword(ExcelUtility.getCellDataCustomer(1, 1));
		CustFrEnd.login.click();
		CustFrEnd.flights.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		AdmBaEnd = new AdminBackEnd(driver);
		AdmBaEnd.bookings();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(prop.getProperty("AdminLogin"));
		driver.manage().window().maximize();
		AdmBaEnd.setEmail(ExcelUtility.getCellDataAdmin(1, 0));
		AdmBaEnd.setPassword(ExcelUtility.getCellDataAdmin(1, 1));
		AdmBaEnd.login.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("AdminDashboard");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Exp, Act);
	}

	@Test(priority = 1)
	public void TC029_VerifyPaidBookingsInvoice() throws InterruptedException {
		AdmBaEnd = new AdminBackEnd(driver);
		AdmBaEnd.Bookings.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AdmBaEnd.unpaidBookings.click();
		AdmBaEnd.dropdown.click();
		AdmBaEnd.statusPaid.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AdmBaEnd.PaidBookings.click();
		int totalRowNumber = AdmBaEnd.rowNo.size();
		if (totalRowNumber > 1) {
			AssertJUnit.assertTrue(true);
		}
		AdmBaEnd.invoice.click();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		String ActualString = driver.getTitle();
		Assert.assertTrue(ActualString.contains("Invoice"));
		driver.close();

		driver.switchTo().window(tabs2.get(0));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AdmBaEnd.PaidBookings.click();
		String CurrentExp = prop.getProperty("AdminPaidBookings");
		String CurrentAct = driver.getCurrentUrl();
		Assert.assertEquals(CurrentAct, CurrentExp);

	}

	@Test(priority = 2)
	public void TC030_VerifyDeleteBookings() throws InterruptedException, IOException {

		AdmBaEnd = new AdminBackEnd(driver);
		AdmBaEnd.Bookings.click();
		AdmBaEnd.unpaidBookings.click();
		AdmBaEnd.statusBooking.click();
		AdmBaEnd.cancelled.click();
		AdmBaEnd.cancelledBookings.click();
		String first = AdmBaEnd.cancelledCount.getText();
		AdmBaEnd.delete.click();

		Alert alert = driver.switchTo().alert();
		String actual = driver.switchTo().alert().getText();
		String expected = AutomationConstants.ALERT_MESSAGE;
		Assert.assertEquals(expected, actual);
		alert.accept();
		Thread.sleep(2000);

		AdmBaEnd.cancelledBookings.click();
		String second = AdmBaEnd.cancelledCount.getText();
		Assert.assertNotEquals(first, second);

	}

	@Test(priority = 3)
	public void TC031_VerifyBookingsCount() throws InterruptedException {
		AdmBaEnd = new AdminBackEnd(driver);
		AdmBaEnd.Bookings.click();
		AdmBaEnd.PendingBookings.click();
		String pendingCountFirst = AdmBaEnd.pendingCount.getText();
		String confirmedCountFirst = AdmBaEnd.confirmedCount.getText();
		AdmBaEnd.dropdownBookingStatus.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AdmBaEnd.confirmedDD.click();
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String pendingCountLast = AdmBaEnd.pendingCount.getText();
		String confirmedCountLast = AdmBaEnd.confirmedCount.getText();
		Assert.assertNotEquals(pendingCountFirst, pendingCountLast);
		Assert.assertNotEquals(confirmedCountFirst, confirmedCountLast);
	}

}
