package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import net.PhpTravels.constants.AutomationConstants;
import net.PhpTravels.pages.CustomerFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassCusFrontEnd_Login extends TestBase {

	CustomerFrontEnd CustFrEnd;

	@Test(priority = 3)
	public void TC001_VerifyLoginValid() throws IOException {
		CustFrEnd = new CustomerFrontEnd(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		CustFrEnd.setEmail(ExcelUtility.getCellDataCustomer(1, 0));
		CustFrEnd.setPassword(ExcelUtility.getCellDataCustomer(1, 1));
		CustFrEnd.login.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("FrontEndDashboard");
		String Act = driver.getCurrentUrl();
		AssertJUnit.assertEquals(Exp, Act);
	}

	@Test(priority = 1)
	public void TC002_VerifyLoginInvalidEmail() throws IOException, InterruptedException {
		CustFrEnd = new CustomerFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
		driver.manage().window().maximize();
		CustFrEnd.setEmail(ExcelUtility.getCellDataCustomer(2, 0));
		CustFrEnd.setPassword(ExcelUtility.getCellDataCustomer(2, 1));
		CustFrEnd.login.click();
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement el = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='alert alert-danger failed']")));
		AssertJUnit.assertTrue(el.getText().contains(AutomationConstants.LOGIN_ERROR_MESSAGE));
	}

	@Test(priority = 2)
	public void TC003_VerifyLoginInvalidPassword() throws IOException, InterruptedException {
		CustFrEnd = new CustomerFrontEnd(driver);
		CustFrEnd.setEmail(ExcelUtility.getCellDataCustomer(3, 0));
		CustFrEnd.setPassword(ExcelUtility.getCellDataCustomer(3, 1));
		CustFrEnd.login.click();
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement el = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='alert alert-danger failed']")));
		AssertJUnit.assertTrue(el.getText().contains(AutomationConstants.LOGIN_ERROR_MESSAGE));
	}

}
