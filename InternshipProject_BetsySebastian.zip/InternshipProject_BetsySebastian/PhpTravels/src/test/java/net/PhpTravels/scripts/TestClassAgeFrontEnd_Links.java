package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import net.PhpTravels.pages.AgentFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassAgeFrontEnd_Links extends TestBase{
	
AgentFrontEnd AgeFrEnd;

	@BeforeClass
	public void Login() throws IOException {
		AgeFrEnd = new AgentFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
	  driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AgeFrEnd.setEmail(ExcelUtility.getCellDataAgent(1, 0));
		AgeFrEnd.setPassword(ExcelUtility.getCellDataAgent(1, 1));
		AgeFrEnd.login.click();
	}
	
	@Test (priority=2)
	public void TC018_VerifyBookingsLink() {
		AgeFrEnd = new AgentFrontEnd(driver);
		AgeFrEnd.myBookings.click();
		String Exp = prop.getProperty("FrontEndBookings");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
	}

	@Test (priority=3)
	public void TC019_VerifyAddFundLink() {
		AgeFrEnd = new AgentFrontEnd(driver);
		AgeFrEnd.addFund.click();
		String Exp = prop.getProperty("FrontEndAddFunds");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
	}
	
	@Test (priority=4)
	public void TC020_VerifyMyProfileLink() {
		AgeFrEnd = new AgentFrontEnd(driver);
		AgeFrEnd.myProfile.click();
		String Exp = prop.getProperty("FrontEndProfile");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
	}
	
	@Test (priority=6)
	public void TC021_VerifyLogoutLink() {
		AgeFrEnd = new AgentFrontEnd(driver);
		AgeFrEnd.Logout.click();
		String Exp = prop.getProperty("FrontEndLogin");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
	}
	
	@Test (priority=5)
	public void TC022_VerifyTopPageLinks() {
		AgeFrEnd = new AgentFrontEnd(driver);
		
		AgeFrEnd.topHome.click();
		String Exp = prop.getProperty("FrontEndHome");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
		
		AgeFrEnd.topHotels.click();
		String Exp1 = prop.getProperty("FrontEndHotels");
		String Act1 = driver.getCurrentUrl();
		Assert.assertEquals(Act1, Exp1);
		
		AgeFrEnd.topTours.click();
		String Exp2 = prop.getProperty("FrontEndTours");
		String Act2 = driver.getCurrentUrl();
		Assert.assertEquals(Act2, Exp2);
		
		AgeFrEnd.topFlights.click();
		String Exp3 = prop.getProperty("FrontEndFlights");
		String Act3 = driver.getCurrentUrl();
		Assert.assertEquals(Act3, Exp3);
		
		AgeFrEnd.topVisa.click();
		String Exp4 = prop.getProperty("FrontEndVisa");
		String Act4 = driver.getCurrentUrl();
		Assert.assertEquals(Act4, Exp4);
		
		AgeFrEnd.topBlog.click();
		String Exp5 = prop.getProperty("FrontEndBlog");
		String Act5 = driver.getCurrentUrl();
		Assert.assertEquals(Act5, Exp5);
		
		AgeFrEnd.topOffers.click();
		String Exp6 = prop.getProperty("FrontEndOffers");
		String Act6 = driver.getCurrentUrl();
		Assert.assertEquals(Act6, Exp6);
		
		driver.navigate().to(prop.getProperty("FrontEndDashboard"));
		String Exp7 = prop.getProperty("FrontEndDashboard");
		String Act7 = driver.getCurrentUrl();
		Assert.assertEquals(Act7, Exp7);
	}
}


