package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import net.PhpTravels.constants.AutomationConstants;
import net.PhpTravels.pages.SupplierBackEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassSupBackEnd_Links extends TestBase {

	SupplierBackEnd SupBaEnd;

	@BeforeClass
	public void SupplierLogin() throws IOException {
		SupBaEnd = new SupplierBackEnd(driver);
		driver.get(prop.getProperty("SupplierLogin"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		SupBaEnd.setEmail(ExcelUtility.getCellDataSupplier(1, 0));
		SupBaEnd.setPassword(ExcelUtility.getCellDataSupplier(1, 1));
		SupBaEnd.login.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("SupplierDashboard");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Exp, Act);
	}

	@Test(priority = 1)
	public void TC039_VerifyFlightsLink() {
		SupBaEnd = new SupplierBackEnd(driver);
		SupBaEnd.isPresent(By.id("Flights"));
	}

	@Test(priority = 2)
	public void TC040_VerifyVisaLink() {
		SupBaEnd = new SupplierBackEnd(driver);
		SupBaEnd.isPresent(By.id("Visa"));
	}

	@Test(priority = 3)
	public void TC041_VerifyToursLink() throws InterruptedException {
		SupBaEnd = new SupplierBackEnd(driver);

		JavascriptExecutor jsr = (JavascriptExecutor) driver;
		jsr.executeScript("document.getElementsByClassName('material-icons')[14].click()");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		JavascriptExecutor jst = (JavascriptExecutor) driver;
		jst.executeScript("document.getElementsByClassName('material-icons')[15].click()");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("document.getElementsByClassName('nav-link mdc-ripple-upgraded')[38].click()");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		String act = prop.getProperty("SupplierTours");
		String exp = driver.getCurrentUrl();
		Assert.assertEquals(exp, act);

	}

	@Test(priority = 4)
	public void TC042_VerifyBookingsLink() {
		SupBaEnd = new SupplierBackEnd(driver);
		SupBaEnd.topBooking.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String act = driver.getTitle();
		String exp = AutomationConstants.BOOKING_TITLE;
		Assert.assertEquals(act, exp);
	}

}
