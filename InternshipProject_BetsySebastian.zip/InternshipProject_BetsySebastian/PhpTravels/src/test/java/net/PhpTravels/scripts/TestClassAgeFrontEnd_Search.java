package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import net.PhpTravels.pages.AgentFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassAgeFrontEnd_Search extends TestBase{
	
	AgentFrontEnd AgeFrEnd;

	@BeforeClass
	public void Login() throws IOException {
		AgeFrEnd = new AgentFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
	  driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AgeFrEnd.setEmail(ExcelUtility.getCellDataAgent(1, 0));
		AgeFrEnd.setPassword(ExcelUtility.getCellDataAgent(1, 1));
		AgeFrEnd.login.click();
	}
	
	@Test (priority=1)
	public void TC023_VerifySearchByCityName() {
		AgeFrEnd = new AgentFrontEnd(driver);
		AgeFrEnd.topHotels.click();
		AgeFrEnd.search.sendKeys("Dubai");
		WebElement textbox = AgeFrEnd.search;
		textbox.sendKeys(Keys.ENTER);
		AgeFrEnd.searchButton.click();
		String ActualString = driver.getTitle();
    Assert.assertTrue(ActualString.contains("Search Hotels - PHPTRAVELS"));			
	}

	
	@Test (priority=2)
	public void TC024_VerifySearchWithoutCityName() {
		AgeFrEnd = new AgentFrontEnd(driver);
		AgeFrEnd.topHotels.click();
		AgeFrEnd.search.sendKeys(" ");
		WebElement textbox = AgeFrEnd.search;
		textbox.sendKeys(Keys.ENTER);
		AgeFrEnd.searchButton.click();
		String Actual= driver.getCurrentUrl();
		String Expected = prop.getProperty("FrontEndHotels");
    Assert.assertEquals(Actual, Expected);	
	}

}
