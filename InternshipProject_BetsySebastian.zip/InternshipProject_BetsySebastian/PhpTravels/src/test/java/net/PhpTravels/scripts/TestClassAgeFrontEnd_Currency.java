package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import net.PhpTravels.pages.AgentFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassAgeFrontEnd_Currency extends TestBase{
	
	AgentFrontEnd AgeFrEnd;

	@BeforeClass
	public void Login() throws IOException {
		AgeFrEnd = new AgentFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
	  driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AgeFrEnd.setEmail(ExcelUtility.getCellDataAgent(1, 0));
		AgeFrEnd.setPassword(ExcelUtility.getCellDataAgent(1, 1));
		AgeFrEnd.login.click();
	}
	
	@Test (priority=1)
	public void TC025_VerifyCurrencyUpdate() {
		AgeFrEnd = new AgentFrontEnd(driver);
		AgeFrEnd.topHome.click();
		AgeFrEnd.currencyDropdown.click();
		AgeFrEnd.INR.click();
	  String expected = "INR";
	  String actual = AgeFrEnd.currencyDropdown.getText();
	  Assert.assertEquals(actual,expected);	 
		
	}

}
