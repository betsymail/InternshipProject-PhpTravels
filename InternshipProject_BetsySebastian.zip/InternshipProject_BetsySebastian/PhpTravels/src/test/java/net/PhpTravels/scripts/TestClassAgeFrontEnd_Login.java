package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import net.PhpTravels.constants.AutomationConstants;
import net.PhpTravels.pages.AgentFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassAgeFrontEnd_Login extends TestBase {

	AgentFrontEnd AgeFrEnd;

	@Test(priority = 3)
	public void TC015_VerifyLoginValid() throws IOException {
		AgeFrEnd = new AgentFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AgeFrEnd.setEmail(ExcelUtility.getCellDataAgent(1, 0));
		AgeFrEnd.setPassword(ExcelUtility.getCellDataAgent(1, 1));
		AgeFrEnd.login.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("FrontEndDashboard");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Exp, Act);
	}

	@Test(priority = 1)
	public void TC016_VerifyLoginInvalidEmail() throws IOException, InterruptedException {
		AgeFrEnd = new AgentFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AgeFrEnd.setEmail(ExcelUtility.getCellDataAgent(2, 0));
		AgeFrEnd.setPassword(ExcelUtility.getCellDataAgent(2, 1));
		AgeFrEnd.login.click();
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement el = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='alert alert-danger failed']")));
		Assert.assertTrue(el.getText().contains(AutomationConstants.LOGIN_ERROR_MESSAGE));
	}

	@Test(priority = 2)
	public void TC017_VerifyLoginInvalidPassword() throws IOException, InterruptedException {
		AgeFrEnd = new AgentFrontEnd(driver);
		AgeFrEnd.setEmail(ExcelUtility.getCellDataAgent(3, 0));
		AgeFrEnd.setPassword(ExcelUtility.getCellDataAgent(3, 1));
		AgeFrEnd.login.click();
		Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement el = wait
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='alert alert-danger failed']")));
		Assert.assertTrue(el.getText().contains(AutomationConstants.LOGIN_ERROR_MESSAGE));
	}

}
