package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.applitools.eyes.selenium.Eyes;
import net.PhpTravels.constants.AutomationConstants;
import net.PhpTravels.pages.SupplierBackEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassSupBackEnd_Dashboard extends TestBase{
	
SupplierBackEnd SupBaEnd;
	
	@BeforeClass
	public void SupplierLogin() throws IOException {
		SupBaEnd = new SupplierBackEnd(driver);
		driver.get(prop.getProperty("SupplierLogin"));
	  driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		SupBaEnd.setEmail(ExcelUtility.getCellDataSupplier(1, 0));
		SupBaEnd.setPassword(ExcelUtility.getCellDataSupplier(1, 1));
		SupBaEnd.login.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("SupplierDashboard");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Exp,Act);
	}
	
	@Test(priority=1)
	public void TC036_VerifyText() {
		SupBaEnd = new SupplierBackEnd(driver);
		driver.get(prop.getProperty("SupplierDashboard"));
		String Exp = SupBaEnd.TextDashboard.getText();
		String Act = AutomationConstants.TEXT_SUPPLIER_DASHBOARD;
		Assert.assertEquals(Exp, Act);
		
	}
	
	@Test(priority=2)
	public void TC037_VerifyDisplayRevenueBreakdown() {
		SupBaEnd = new SupplierBackEnd(driver);
		new Actions(driver).moveToElement(SupBaEnd.revenue).click().perform();
		
		Eyes eyes = new Eyes();
		eyes.setApiKey("fNdHzeP5105NF108W723Qskdu4DZMOOKe397tQ1DPsnzbeWw110");
		eyes.open(driver,"https://www.phptravels.net/api/supplier","RevenueBreakdown");
		eyes.checkElement(SupBaEnd.revenue);
		eyes.close();
		
		System.out.println("TC037 = Revenue Breakdown Display is not visible");
	}
	
}
	