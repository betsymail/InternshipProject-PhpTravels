package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import net.PhpTravels.constants.AutomationConstants;
import net.PhpTravels.pages.CustomerFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassCusFrontEnd_Payments extends TestBase {

	CustomerFrontEnd CustFrEnd;

	@BeforeClass
	public void Login() throws IOException {
		CustFrEnd = new CustomerFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		CustFrEnd.setEmail(ExcelUtility.getCellDataCustomer(1, 0));
		CustFrEnd.setPassword(ExcelUtility.getCellDataCustomer(1, 1));
		CustFrEnd.login.click();
	}

	@Test(priority = 1)
	public void TC008_VerifyPaypalPayment() {
		CustFrEnd = new CustomerFrontEnd(driver);
		CustFrEnd.addFund.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		CustFrEnd.paypal.click();
		CustFrEnd.amount.clear();
		CustFrEnd.amount.sendKeys("50");
		CustFrEnd.paynow.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("PaypalFirst");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);

		CustFrEnd.paypalScreen.click();
		String ExpTitle = AutomationConstants.PAYPAL_TITLE;
		String ActTitle = driver.getTitle();
		Assert.assertEquals(ActTitle, ExpTitle);
	}

	@Test(priority = 2)
	public void TC009_VerifyPaypalPayment() {
		CustFrEnd = new CustomerFrontEnd(driver);
		driver.navigate().to(prop.getProperty("FrontEndDashboard"));
		CustFrEnd.addFund.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		CustFrEnd.paypal.click();
		CustFrEnd.amount.clear();
		CustFrEnd.amount.sendKeys("0");
		CustFrEnd.paynow.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("FrontEndAddFunds");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
	}
}
