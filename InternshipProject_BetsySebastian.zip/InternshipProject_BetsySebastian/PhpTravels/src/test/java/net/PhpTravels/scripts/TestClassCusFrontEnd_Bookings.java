package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import net.PhpTravels.pages.CustomerFrontEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassCusFrontEnd_Bookings extends TestBase {

	CustomerFrontEnd CustFrEnd;

	@BeforeClass
	public void Login() throws IOException {
		CustFrEnd = new CustomerFrontEnd(driver);
		driver.get(prop.getProperty("FrontEndLogin"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		CustFrEnd.setEmail(ExcelUtility.getCellDataCustomer(1, 0));
		CustFrEnd.setPassword(ExcelUtility.getCellDataCustomer(1, 1));
		CustFrEnd.login.click();
	}

	@Test(priority = 1)
	public void TC010_VerifyBookingsVoucher() throws InterruptedException, IOException {
		CustFrEnd = new CustomerFrontEnd(driver);
		CustFrEnd.flights.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		JavascriptExecutor jsr = (JavascriptExecutor) driver;
		jsr.executeScript("document.getElementsByClassName('col-7')[1].click()");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		CustFrEnd.bookNow.click();

		WebElement li = driver.findElement(By.xpath("//input[@id='gateway_bank-transfer']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", li);
		Thread.sleep(800);

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		CustFrEnd.bankTransfer.click();
		CustFrEnd.terms.click();
		CustFrEnd.confirmBooking.click();
		driver.close();

		onSetup();
		Login();
		CustFrEnd.myBookings.click();
		String Exp = prop.getProperty("FrontEndBookings");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Act, Exp);
		CustFrEnd.viewVoucher.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		String ActualString = driver.getTitle();
		Assert.assertTrue(ActualString.contains("Invoice"));
		driver.close();

		driver.switchTo().window(tabs2.get(0));
		String CurrentExp = prop.getProperty("FrontEndBookings");
		String CurrentAct = driver.getCurrentUrl();
		Assert.assertEquals(CurrentAct, CurrentExp);
	}

	@Test(priority = 2)
	public void TC011_VerifyPageScroll() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,500)");
		jse.executeScript("window.scrollBy(0,-500)");

	}
}
