package net.PhpTravels.scripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import net.PhpTravels.pages.AdminBackEnd;
import net.PhpTravels.pages.AgentFrontEnd;
import net.PhpTravels.pages.SupplierBackEnd;
import net.PhpTravels.utilities.ExcelUtility;

public class TestClassSupBackEnd_Bookings extends TestBase {
	SupplierBackEnd SupBaEnd;
	AgentFrontEnd AgeFrEnd;
	AdminBackEnd AdmBaEnd;

	@BeforeClass
	public void SupplierLogin() throws IOException {
		SupBaEnd = new SupplierBackEnd(driver);
		driver.get(prop.getProperty("SupplierLogin"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		SupBaEnd.setEmail(ExcelUtility.getCellDataSupplier(1, 0));
		SupBaEnd.setPassword(ExcelUtility.getCellDataSupplier(1, 1));
		SupBaEnd.login.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String Exp = prop.getProperty("SupplierDashboard");
		String Act = driver.getCurrentUrl();
		Assert.assertEquals(Exp, Act);
	}

	@Test(priority = 1)
	public void TC038_VerifyBookingStatus() throws IOException, InterruptedException {
		SupBaEnd = new SupplierBackEnd(driver);
		SupBaEnd.PendBookings.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		if (driver.findElements(By.xpath("//td//strong[contains(text(),'321.3')]")).size() > 0) {

			driver.get(prop.getProperty("SupplierDashboard"));
			String totalPendingInitial = SupBaEnd.countPen.getText();
			String totalConfirmedInitial = SupBaEnd.countCon.getText();

			SupBaEnd.PendBookings.click();
			SupBaEnd.statusDD.click();
			SupBaEnd.confirmedDD.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(prop.getProperty("SupplierDashboard"));
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			String totalPendingFinal = SupBaEnd.countPen.getText();
			String totalConfirmedFinal = SupBaEnd.countCon.getText();

			Assert.assertNotEquals(totalPendingInitial, totalPendingFinal);
			Assert.assertNotEquals(totalConfirmedInitial, totalConfirmedFinal);

			Thread.sleep(2000);
		} else {

			AdmBaEnd = new AdminBackEnd(driver);
			driver.get(prop.getProperty("AdminLogin"));
			AdmBaEnd.setEmail(ExcelUtility.getCellDataAdmin(1, 0));
			AdmBaEnd.setPassword(ExcelUtility.getCellDataAdmin(1, 1));
			AdmBaEnd.login.click();
			AdmBaEnd.Bookings.click();

			if (driver.findElements(By.xpath("//td//strong[contains(text(),'321.3')]")).size() > 0) {
				AdmBaEnd.deleteBooking.click();
				Alert alert = driver.switchTo().alert();
				alert.accept();
				Thread.sleep(2000);
			}

			AgeFrEnd = new AgentFrontEnd(driver);
			driver.get(prop.getProperty("FrontEndLogin"));
			driver.manage().window().maximize();
			AgeFrEnd.setEmail(ExcelUtility.getCellDataAgent(1, 0));
			AgeFrEnd.setPassword(ExcelUtility.getCellDataAgent(1, 1));
			AgeFrEnd.login.click();

			AgeFrEnd.topHotels.click();
			WebElement l = driver.findElement(By.xpath("//div[7]//div[1]//div[1]//a[1]//img[1]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click()", l);
			Thread.sleep(300);

			JavascriptExecutor jsr = (JavascriptExecutor) driver;
			jsr.executeScript("document.getElementsByClassName('effect ladda effect ladda-button waves-effect')[1].click()");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			JavascriptExecutor jst = (JavascriptExecutor) driver;
			jst.executeScript("document.getElementById('gateway_bank-transfer').click()");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			JavascriptExecutor jsy = (JavascriptExecutor) driver;
			jsy.executeScript("document.getElementById('agreechb').click()");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			JavascriptExecutor jsu = (JavascriptExecutor) driver;
			jsu.executeScript("document.getElementById('booking').click()");

			driver.close();

			onSetup();
			SupBaEnd = new SupplierBackEnd(driver);
			driver.get(prop.getProperty("SupplierLogin"));
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			SupBaEnd.setEmail(ExcelUtility.getCellDataSupplier(1, 0));
			SupBaEnd.setPassword(ExcelUtility.getCellDataSupplier(1, 1));
			SupBaEnd.login.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			String totalPendingInitial = SupBaEnd.countPen.getText();
			String totalConfirmedInitial = SupBaEnd.countCon.getText();

			SupBaEnd.PendBookings.click();
			SupBaEnd.statusDD.click();
			SupBaEnd.confirmedDD.click();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(prop.getProperty("SupplierDashboard"));
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			String totalPendingFinal = SupBaEnd.countPen.getText();
			String totalConfirmedFinal = SupBaEnd.countCon.getText();

			Assert.assertNotEquals(totalPendingInitial, totalPendingFinal);
			Assert.assertNotEquals(totalConfirmedInitial, totalConfirmedFinal);

		}

	}

}
