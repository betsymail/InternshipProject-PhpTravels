package net.PhpTravels.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class CustomerFrontEnd {
	
	 WebDriver driver;
	 
	 @FindBy(xpath ="//input[@placeholder='Email']")
	 private WebElement email;
	 
	 @FindBy(xpath ="//input[@placeholder='Password']")
	 private WebElement password;
	 
	 @FindBy(xpath ="//span[normalize-space()='Login']")
	 public WebElement login;
	 
	 @FindBy(xpath="//div[@class='alert alert-danger failed']")
	 public WebElement loginErrorMessage;
	 
	 @FindBy(xpath ="//ul[@class='sidebar-menu list-items']//a[contains(@class,'waves-effect')][normalize-space()='My Bookings']")
	 public WebElement myBookings;
	 
	 @FindBy(xpath = "//ul[@class='sidebar-menu list-items']//a[@class=' waves-effect'][normalize-space()='Add Funds']")
	 public WebElement addFund;	 
	 
	 @FindBy(xpath ="//ul[@class='sidebar-menu list-items']//a[contains(@class,'waves-effect')][normalize-space()='My Profile']")
	 public WebElement myProfile;
	 
	 @FindBy(xpath = "//ul[@class='sidebar-menu list-items']//a[contains(@class,'waves-effect')][normalize-space()='Logout']")
	 public WebElement Logout;
	 
	 @FindBy(xpath ="//input[@id='gateway_paypal']")
	 public WebElement paypal;
	 
	 @FindBy(xpath = "//input[@name='price']")
	 public WebElement amount;
	 
	 @FindBy (xpath = "//i[@class='la la-arrow-right']")
	 public WebElement paynow;
	 
	 @FindBy (xpath = "//div[@id='paypal-button']")
	 public WebElement paypalScreen;
	 
	 @FindBy (xpath="//a[normalize-space()='flights']")
	 public WebElement flights;
	 
	 
	 @FindBy (xpath="//h6[normalize-space()='Air Phillpines']")
	 public WebElement airPhili;
	 
	 @FindBy (xpath ="//li[1]//div[1]//form[1]//div[1]//div[2]//div[1]//button[1]//span[1]")
	 public WebElement bookNow;
	 
	 @FindBy (xpath="//input[@id='gateway_bank-transfer']")
	 public WebElement bankTransfer;
	 
	 @FindBy (xpath="//label[@for='agreechb']")
	 public WebElement terms;
	 
	 @FindBy (xpath="//button[@id='booking']")
	 public WebElement confirmBooking;
	 
	 @FindBy (xpath="//tbody/tr[1]/td[4]/div[1]/a[1]")
	 public WebElement viewVoucher;
	 
	 @FindBy (xpath="//li[@class='page-active']//a[contains(@class,'waves-effect')][normalize-space()='My Profile']")
	 public WebElement address;
	 
	 @FindBy (xpath="//input[@name='address1']")
	 public WebElement Address1;
	 
	 @FindBy (xpath="//input[@name='address2']")
	 public WebElement Address2;
	 
	 
	 
	 
	 public CustomerFrontEnd(WebDriver driver){
     this.driver = driver;
     PageFactory.initElements(driver, this);
 }

	 public void setEmail(String strEmail) {
		  email.sendKeys(strEmail);
				
		}
	 
	 public void setPassword(String strPassword) {
		  password.sendKeys(strPassword);
				
		}
	 

}
