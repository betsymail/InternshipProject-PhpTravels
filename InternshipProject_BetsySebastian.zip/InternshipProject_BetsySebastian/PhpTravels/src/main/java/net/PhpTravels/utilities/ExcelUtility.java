package net.PhpTravels.utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {

	private static      XSSFWorkbook excelWBook; 
  private static      XSSFSheet    excelWSheet; 
 

  
 public static String getCellDataCustomer(int RowNum, int ColNum) throws IOException {
    
  
   FileInputStream ExcelFile = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources" + "/Testdata.xlsx");
   excelWBook = new XSSFWorkbook(ExcelFile);
     excelWSheet = excelWBook.getSheetAt(0);
     return excelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();

 }
 
 public static String getCellDataAgent(int RowNum, int ColNum) throws IOException {
   
	  
   FileInputStream ExcelFile = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources" + "/Testdata.xlsx");
   excelWBook = new XSSFWorkbook(ExcelFile);
     excelWSheet = excelWBook.getSheetAt(1);
     return excelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();

 }
 
 public static String getCellDataAdmin(int RowNum, int ColNum) throws IOException {
   
	  
   FileInputStream ExcelFile = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources" + "/Testdata.xlsx");
   excelWBook = new XSSFWorkbook(ExcelFile);
     excelWSheet = excelWBook.getSheetAt(2);
     return excelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();

 }
 
 public static String getCellDataSupplier(int RowNum, int ColNum) throws IOException {
   
	  
   FileInputStream ExcelFile = new FileInputStream(System.getProperty("user.dir") + "/src/main/resources" + "/Testdata.xlsx");
   excelWBook = new XSSFWorkbook(ExcelFile);
     excelWSheet = excelWBook.getSheetAt(3);
     return excelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();

 }
 
 
}
