package net.PhpTravels.constants;

public class AutomationConstants {

	public static final String LOGIN_ERROR_MESSAGE = "Wrong credentials. try again!";
	public static final String PAYPAL_TITLE = "Payment with paypal";
	public static final String BACKEND_LOGIN_ERROR_MESSAGE = "Invalid Login Credentials";
	public static final String ALERT_MESSAGE = "Are you sure to delete?";
	public static final String TEXT_SUPPLIER_DASHBOARD = "Sales overview & summary";
	public static final String BOOKING_TITLE = "Bookings";
	public static final String ERROR_TITLE = "Error";

}
