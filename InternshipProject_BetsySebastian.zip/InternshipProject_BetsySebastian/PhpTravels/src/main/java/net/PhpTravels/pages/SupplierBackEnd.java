package net.PhpTravels.pages;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupplierBackEnd {

	WebDriver driver;

	@FindBy(xpath = "//input[@type='text']")
	private WebElement email;

	@FindBy(xpath = "//input[@name='password']")
	private WebElement password;

	@FindBy(xpath = "//span[normalize-space()='Login']")
	public WebElement login;

	@FindBy(xpath = "//div[@class='text-muted']")
	public WebElement TextDashboard;

	@FindBy(xpath = "//canvas[@id='dashboardBarChart']")
	public WebElement revenue;

	@FindBy(xpath = "//div[@class='card card-raised border-start border-warning border-4 pending_']//div[@class='display-5']")
	public WebElement countPen;

	@FindBy(xpath = "//div[normalize-space()='Pending Bookings']")
	public WebElement PendBookings;

	@FindBy(xpath = "//a[normalize-space()='Bookings']")
	public WebElement topBooking;

	@FindBy(xpath = "//select[@id='booking_status']")
	public WebElement statusDD;

	@FindBy(xpath = "//select[@id='booking_status']/child::option[contains(text(),'Confirmed')]")
	public WebElement confirmedDD;

	@FindBy(xpath = "//div[@class='card card-raised border-start border-info border-4 confirmed_']//div[@class='display-5']")
	public WebElement countCon;

	@FindBy(id = "Flights")
	public WebElement Flights;

	@FindBy(id = "Visa")
	public WebElement Visa;

	@FindBy(xpath = "//a[@class='nav-link mdc-ripple-upgraded mdc-ripple-upgraded--background-focused']//i[@class='material-icons'][normalize-space()='expand_more']")
	public WebElement Tours1;

	@FindBy(xpath = "//div[@id='toursmodule']//i[@class='material-icons'][normalize-space()='expand_more']")
	public WebElement Tours2;

	@FindBy(xpath = "//a[normalize-space()='Manage Tours']")
	public WebElement manageTours;

	@FindBy(xpath = "//p[contains(text(),'Unable to load the requested file: admin/template.')]")
	public WebElement errorMessage;

	public SupplierBackEnd(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clearEmail() {
		email.clear();
	}

	public void setEmail(String strEmail) {
		email.sendKeys(strEmail);

	}

	public void clearPassword() {
		password.clear();
	}

	public void setPassword(String strPassword) {
		password.sendKeys(strPassword);

	}

	public boolean isPresent(By id) {
		try {
			Flights.findElement(id);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

}
