package net.PhpTravels.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminBackEnd {

	WebDriver driver;

	@FindBy(xpath = "//input[@type='text']")
	private WebElement email;

	@FindBy(xpath = "//input[@name='password']")
	private WebElement password;

	@FindBy(xpath = "//span[normalize-space()='Login']")
	public WebElement login;

	@FindBy(xpath = "//a[@class='nav-link loadeffect']")
	public WebElement Bookings;

	@FindBy(xpath = "//div[normalize-space()='Pending Bookings']")
	public WebElement PendingBookings;

	@FindBy(xpath = "//div[normalize-space()='Unpaid Bookings']")
	public WebElement unpaidBookings;

	@FindBy(xpath = "//div[normalize-space()='Cancelled Bookings']")
	public WebElement cancelledBookings;

	@FindBy(xpath = "//select[@id='booking_status']")
	public WebElement statusBooking;

	@FindBy(xpath = "//select[@id='booking_status']//child::option[contains(text(),'Cancelled')]")
	public WebElement cancelled;

	@FindBy(xpath = "//button[@class='btn btn-danger mdc-ripple-upgraded']")
	public WebElement delete;

	@FindBy(xpath = "//div[@class='card card-raised border-start border-danger border-4 cancelled_']//div[@class='display-5']")
	public WebElement cancelledCount;

	@FindBy(xpath = "//div[@class='card card-raised border-start border-secondary border-4 unpaid_']//div[@class='display-5']")
	public WebElement unpaidCount;

	@FindBy(xpath = "//div[@class='card card-raised border-start border-warning border-4 pending_']//div[@class='display-5']")
	public WebElement pendingCount;

	@FindBy(xpath = "//div[@class='card card-raised border-start border-info border-4 confirmed_']//div[@class='display-5']")
	public WebElement confirmedCount;

	@FindBy(xpath = "(//select[@id='booking_status'])[1]")
	public WebElement dropdownBookingStatus;

	@FindBy(xpath = "(//select[@id='booking_status'])[1]//option[contains(text(),'Confirmed')]")
	public WebElement confirmedDD;

	@FindBy(xpath = "(//select[@id='payment_status'])[1]")
	public WebElement dropdown;

	@FindBy(xpath = "(//select[@id='payment_status'])[1]//option[@class='Paid']")
	public WebElement statusPaid;

	@FindBy(xpath = "//div[normalize-space()='Paid Bookings']")
	public WebElement PaidBookings;

	@FindBy(xpath = "//a[@class='btn btn-outline-dark mdc-ripple-upgraded']")
	public WebElement invoice;

	@FindBy(xpath = "//table//tr//td[@class='xcrud-current xcrud-num sorting_1']")
	public List<WebElement> rowNo;

	@FindBy(xpath = "//a[normalize-space()='Website']")
	public WebElement websiteLink;

	@FindBy(xpath = "//table[@id='data']")
	public WebElement table;

	@FindBy(xpath = "//table[@id='data']/tbody/tr")
	public List<WebElement> allRows;

	@FindBy(xpath = "//td//strong[contains(text(),'321.3')]/following::td[6]")
	public WebElement deleteBooking;

	@FindBy(xpath = "//a[normalize-space()='flights']")
	public WebElement flights;

	@FindBy(xpath = "//li[1]//div[1]//form[1]//div[1]//div[2]//div[1]//button[1]//span[1]")
	public WebElement bookNow;

	@FindBy(xpath = "//input[@id='gateway_bank-transfer']")
	public WebElement bankTransfer;

	@FindBy(xpath = "//label[@for='agreechb']")
	public WebElement terms;

	@FindBy(xpath = "//button[@id='booking']")
	public WebElement confirmBooking;

	public AdminBackEnd(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clearEmail() {
		email.clear();
	}

	public void setEmail(String strEmail) {
		email.sendKeys(strEmail);

	}

	public void clearPassword() {
		password.clear();
	}

	public void setPassword(String strPassword) {
		password.sendKeys(strPassword);

	}

	public void bookings() {

		flights.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		JavascriptExecutor jsr = (JavascriptExecutor) driver;
		jsr.executeScript("document.getElementsByClassName('col-7')[1].click()");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		bookNow.click();

		JavascriptExecutor jst = (JavascriptExecutor) driver;
		jst.executeScript("document.getElementsByClassName('form-check-input mx-auto')[0].click()");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		JavascriptExecutor jsy = (JavascriptExecutor) driver;
		jsy.executeScript("document.getElementsByClassName('custom-checkbox')[0].click()");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("document.getElementsByClassName('theme-btn book waves-effect')[0].click()");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

}
