package net.PhpTravels.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentFrontEnd {

	WebDriver driver;

	@FindBy(xpath = "//input[@placeholder='Email']")
	private WebElement email;

	@FindBy(xpath = "//input[@placeholder='Password']")
	private WebElement password;

	@FindBy(xpath = "//span[normalize-space()='Login']")
	public WebElement login;

	@FindBy(xpath = "//div[@class='alert alert-danger failed']")
	public WebElement loginErrorMessage;

	@FindBy(xpath = "//ul[@class='sidebar-menu list-items']//a[contains(@class,'waves-effect')][normalize-space()='My Bookings']")
	public WebElement myBookings;

	@FindBy(xpath = "//ul[@class='sidebar-menu list-items']//a[@class=' waves-effect'][normalize-space()='Add Funds']")
	public WebElement addFund;

	@FindBy(xpath = "//ul[@class='sidebar-menu list-items']//a[contains(@class,'waves-effect')][normalize-space()='My Profile']")
	public WebElement myProfile;

	@FindBy(xpath = "//ul[@class='sidebar-menu list-items']//a[contains(@class,'waves-effect')][normalize-space()='Logout']")
	public WebElement Logout;

	@FindBy(xpath = "//a[normalize-space()='Home']")
	public WebElement topHome;

	@FindBy(xpath = "//a[normalize-space()='Hotels']")
	public WebElement topHotels;

	@FindBy(xpath = "//a[normalize-space()='Tours']")
	public WebElement topTours;

	@FindBy(xpath = "//a[normalize-space()='flights']")
	public WebElement topFlights;

	@FindBy(xpath = "//a[normalize-space()='visa']")
	public WebElement topVisa;

	@FindBy(xpath = "//a[normalize-space()='Blog']")
	public WebElement topBlog;

	@FindBy(xpath = "//a[normalize-space()='Offers']")
	public WebElement topOffers;

	@FindBy(xpath = "//span[@role='combobox']")
	public WebElement search;

	@FindBy(xpath = "//span[@class='ladda-label']")
	public WebElement searchButton;

	@FindBy(xpath = "//div[contains(@class,'pt-1 pe-2 multi_currency')]//button[@id='currency']")
	public WebElement currencyDropdown;

	@FindBy(xpath = "//a[normalize-space()='INR']")
	public WebElement INR;

	@FindBy(xpath = "//div[@class='owl-item active']//a[contains(@class,'waves-effect')][normalize-space()='Hyatt Regency Perth']")
	public WebElement Hyatt;

	@FindBy(xpath = "//div[@class='col-md-3 booked_44']//button[@type='submit']")
	public WebElement HyattBooknow;

	@FindBy(xpath = "//input[@id='gateway_bank-transfer']")
	public WebElement BankTransfer;

	@FindBy(xpath = "//label[@for='agreechb']")
	public WebElement termsAgree;

	@FindBy(xpath = "//button[@id='booking']")
	public WebElement confirmBooking;

	public AgentFrontEnd(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void setEmail(String strEmail) {
		email.sendKeys(strEmail);

	}

	public void setPassword(String strPassword) {
		password.sendKeys(strPassword);

	}
}
